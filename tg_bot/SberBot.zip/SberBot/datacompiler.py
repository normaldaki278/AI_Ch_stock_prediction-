from moexalgo import session, Ticker
from datetime import datetime, timedelta
import plotly.graph_objects as go
import plotly.subplots as sp
import pandas as pd
from telebot.types import InputFile
from io import BytesIO

from model import create_windowed_df

username = "ivsa0111@gmail.com"
password = "xi+9eeh2Qa5xMgP"
tickers = {name:Ticker(name) for name in ["SIBN", "SMLT", "YDEX", "AGRO", "MTSS", "CHMF", "SBER", "VKCO"]}


def authorise():
    session.authorize(username, password)


def get_info(name: str) -> tuple:
    # Получение вводных
    ticker = tickers[name]
    start = (datetime.today() - timedelta(days=5)).strftime("%Y-%m-%d")
    end = datetime.today().strftime("%Y-%m-%d")


    # Получение всех статистик
    df_candles = ticker.candles(start=start, end=end, period=1)
    df_obstats = ticker.obstats(start=start, end=end)
    df_orderstats = ticker.orderstats(start=start, end=end)
    current_price = df_candles["close"].iloc[-1]
    model_output = create_windowed_df(ticker_df=df_candles, df_OrderStats=df_orderstats,df_OBSTATS=df_obstats, ticker_name=name)
    model_output2 = create_windowed_df(ticker_df=df_candles, df_OrderStats=df_orderstats,df_OBSTATS=df_obstats, ticker_name=name, model=2)


    # Получение графика линии
    df = df_candles[df_candles['end'] > (datetime.today() - timedelta(hours=6))].copy()
    df['end'] = df['end'].dt.time
    line_plot = draw_line_plot(name, end, df['end'].to_list(), df['close'].to_list(), model_output['predict'])


    # Получение графика и вывода модели
    return (model_output, current_price, line_plot, model_output2['predict'])


def draw_line_plot(name: str, date: str, timestapms: list, values: list, predict: float) -> InputFile:
    last_timestamp = (datetime.now() + timedelta(hours=1)).time()
    fig = go.Figure()

    fig.add_trace(go.Scattergl(
        x=timestapms,
        y=values,
        mode="lines",
        name="Before predict",
        line=dict(color="blue"),
        hoverinfo='skip'
    ))

    fig.add_trace(go.Scattergl(
        x=[last_timestamp],
        y=[predict],
        mode="markers",
        name="Predict",
        line=dict(color="red", width=3),
        marker=dict(size=5, color='red'),
        hoverinfo='skip'
    ))
    fig.add_hline(y=predict, line_width=0.5, line_dash="dash", line_color="red")

    fig.update_layout(
        title=f"Цена {name} за {date}",
        yaxis_title='Цена акции',
        template="plotly_white"
    )
    fig.update_xaxes(tickangle=-45, dtick=30)


    image_bytes = BytesIO(fig.to_image(format="png"))
    return InputFile(image_bytes)


def draw_candle_plot(name: str, predict: float) -> InputFile:
    # Обработка данных
    ticker = tickers[name]
    date = datetime.today().strftime("%Y-%m-%d")
    df = ticker.candles(start=date, end=date, period=1)
    df = df[df['end'] > (datetime.now() - timedelta(hours=2))]
    df['end'] = df['end'].dt.time


    fig = sp.make_subplots(specs=[[{"secondary_y": True}]])

    for _, row in df.iterrows():
        fig.add_trace(go.Candlestick(
            x=[row['end']],
            open=[row['open']],
            high=[row['high']],
            low=[row['low']],
            close=[row['close']],
            name=""
        ), secondary_y=False)
    fig.add_trace(go.Bar(x=df['end'], y=df['volume'], name='Volume', marker=dict(color="rgba(255,110,110,0.1)")), secondary_y=True)
    fig.add_hline(y=predict, line_width=0.5, line_dash="dash", line_color="black")


    fig.update_layout(title_text=f'График цены {name} за {datetime.today().strftime("%Y-%m-%d")}',
                      showlegend=False,
                      template="plotly_white",
                      xaxis_rangeslider_visible=False,
                      )
    fig.update_yaxes(title_text='Цена в рублях')
    fig.update_yaxes(title_text='Объём торгов', secondary_y=True)
    fig.update_xaxes(tickangle=-45, dtick=15)

    image_bytes = BytesIO(fig.to_image(format="png"))
    return InputFile(image_bytes)