import pandas as pd
import numpy as np
from xgboost import XGBRegressor
import pandas_ta as ta

XGB = XGBRegressor()
XGB.load_model('Config/xgb_model.bin')

XGB2 = XGBRegressor()
XGB2.load_model('Config/xgb_model2.bin')

indicator_columns = ['SMA_10', 'SMA_30', 'EMA_10', 'RSI', 'MACD', 'CDLDOJI', 'pattern_name']

list_obstats = ['spread_bbo', 'spread_lv10', 'spread_1mio', 'levels_b', 'levels_s',
       'vol_b', 'vol_s', 'val_b', 'val_s', 'imbalance_vol_bbo',
       'imbalance_val_bbo', 'imbalance_vol', 'imbalance_val', 'vwap_b',
       'vwap_s', 'vwap_b_1mio', 'vwap_s_1mio']

list_orderstats = ['put_orders_b', 'put_orders_s', 'put_val_b', 'put_val_s', 'put_vol_b',
       'put_vol_s', 'put_vwap_b', 'put_vwap_s', 'put_vol', 'put_val',
       'put_orders', 'cancel_orders_b', 'cancel_orders_s', 'cancel_val_b',
       'cancel_val_s', 'cancel_vol_b', 'cancel_vol_s', 'cancel_vwap_b',
       'cancel_vwap_s', 'cancel_vol', 'cancel_val']

loaded_columns = pd.read_csv('Config/column_names.csv')
column_names = loaded_columns.squeeze().tolist()

pattern_names = [
    "Восходящий тренд с перепроданностью",
    "Восходящий тренд с перекупленностью",
    "Формирование Doji",
    "Перепроданность",
    "Перекупленность",
    "Нет четкого паттерна"
]
CDLDOJI_vals = ['0', '100']



def identify_pattern(data: pd.DataFrame):
    """Определяет паттерн на основе последних 120 минут данных."""
    sma_10 = data['SMA_10'].iloc[-1]
    sma_30 = data['SMA_30'].iloc[-1]
    rsi = data['RSI'].iloc[-1]
    cdl_doji = data['CDLDOJI'].iloc[-1]

    if sma_10 > sma_30 and rsi < 30:
        return "Восходящий тренд с перепроданностью"
    elif sma_10 < sma_30 and rsi > 70:
        return "Восходящий тренд с перекупленностью"
    elif cdl_doji != 0:
        return "Формирование Doji"
    elif rsi < 30:
        return "Перепроданность"
    elif rsi > 70:
        return "Перекупленность"
    else:
        return "Нет четкого паттерна"


def create_windowed_df(ticker_df: pd.DataFrame, df_OBSTATS: pd.DataFrame, df_OrderStats: pd.DataFrame, ticker_name: str, window_size1 = 90, window_size2 = 60 * 28, model: int = 1):
    result = []
    agg_dict = {
        'open': 'first',
        'high': 'max',
        'low': 'min',
        'close': 'last',
        'value': 'sum',
        'volume': 'sum'
    }


    ticker_df['datetime'] = pd.to_datetime(ticker_df['begin']) + pd.Timedelta(minutes=1)
    ticker_df = ticker_df.drop(columns = ['begin', 'end'])
    ticker_df = ticker_df.sort_values(by = 'datetime')
    ticker_df = ticker_df.set_index('datetime')

    ticker_df['SMA_10'] = ta.sma(ticker_df['close'], length=10)
    ticker_df['SMA_30'] = ta.sma(ticker_df['close'], length=30)
    ticker_df['EMA_10'] = ta.ema(ticker_df['close'], length=10)
    ticker_df['RSI'] = ta.rsi(ticker_df['close'], length=14)
    macd = ta.macd(ticker_df['close'], fast=12, slow=26)
    ticker_df['MACD'] = macd['MACD_12_26_9']
    ticker_df['CDLDOJI'] = ta.cdl_doji(ticker_df['open'], ticker_df['high'], ticker_df['low'], ticker_df['close'])

    i = len(ticker_df) - 1
    last_120_minutes = ticker_df.iloc[i-window_size1:i]
    pattern_name = identify_pattern(last_120_minutes)

    window_data1 = ticker_df.iloc[i-window_size1:i][['open', 'high', 'low', 'close', 'value', 'volume']].values.flatten()

    # Данные для окна X часов почасно
    hourly_data = ticker_df.iloc[i-window_size2:i]
    aggregated_data = hourly_data.groupby(np.arange(len(hourly_data)) // 60).agg(agg_dict)
    window_data2 = aggregated_data.values.flatten()

    ticker = ticker_name
    # Извлечение текущих данных тикера и времени
    current_ticker = ticker
    current_datetime = ticker_df.index[i]

    sma_10 = ticker_df.iloc[i]['SMA_10']
    sma_30 = ticker_df.iloc[i]['SMA_30']
    ema_10 = ticker_df.iloc[i]['EMA_10']
    rsi = ticker_df.iloc[i]['RSI']
    macd_value = ticker_df.iloc[i]['MACD']

    cdl_doji = ticker_df.iloc[i]['CDLDOJI']

    result.append([ current_ticker, current_datetime, sma_10, sma_30, ema_10, rsi, macd_value, cdl_doji, pattern_name] + list(window_data1) + list(window_data2))

    indicator_columns = ['SMA_10', 'SMA_30', 'EMA_10', 'RSI', 'MACD', 'CDLDOJI', 'pattern_name']

    # Создание финального DataFrame
    window_columns1 = [f'{feature}_minute_{j}' for j in range(window_size1) for feature in ['open', 'high', 'low', 'close', 'value', 'volume']]
    num_hours = int(window_size2 / 60)
    window_columns2 = [f'{feature}_hour_{j}' for j in range(num_hours) for feature in ['open', 'high', 'low', 'close', 'value', 'volume']]

    all_columns = ['ticker', 'datetime'] + indicator_columns + window_columns1 + window_columns2

    ticker_df = pd.DataFrame(result, columns=all_columns)

    row_datetime = ticker_df.iloc[0]['datetime']

    df_OBSTATS['datetime'] = pd.to_datetime(df_OBSTATS['tradedate'].astype(str) + ' ' + df_OBSTATS['tradetime'].astype(str))
    df_OBSTATS = df_OBSTATS.sort_values(by='datetime')
    df_OrderStats['datetime'] = pd.to_datetime(df_OrderStats['tradedate'].astype(str) + ' ' + df_OrderStats['tradetime'].astype(str))
    df_OrderStats = df_OrderStats.sort_values(by='datetime')

    closest_OBSTATS_row = df_OBSTATS[df_OBSTATS['datetime'] <= row_datetime].iloc[-1]
    for col in list_obstats:
        ticker_df.loc[0, col] = closest_OBSTATS_row[col]
    closest_OrderStats_row = df_OrderStats[df_OrderStats['datetime'] <= row_datetime].iloc[-1]
    for col in list_orderstats:
        ticker_df.loc[0, col] = closest_OrderStats_row[col] 

    current_columns = list_obstats + window_columns1 + window_columns2 + indicator_columns + list_orderstats

    cat_features = ['ticker'] + ['CDLDOJI', 'pattern_name'] 

    df_all = ticker_df.copy()

    df_all = df_all[current_columns + ['ticker', 'datetime']]

    df_all_encoded = pd.get_dummies(df_all, columns=cat_features)

    train_tickers = ['SIBN', 'SMLT', 'YDEX', 'AGRO', 'MTSS', 'CHMF', 'SBER', 'VKCO']

    # Для каждого тикера, которого нет в df_all_encoded, добавляем столбец с 0
    for ticker in train_tickers:
        ticker_col = f'ticker_{ticker}'
        if ticker_col not in df_all_encoded.columns:
            df_all_encoded[ticker_col] = 0

    for pattern_name in pattern_names:
        pattern_col = f'pattern_name_{pattern_name}'
        if pattern_col not in df_all_encoded.columns:
            df_all_encoded[pattern_col] = 0



    for CDLDOJI in CDLDOJI_vals:
        CDLDOJI_col = f'CDLDOJI_{CDLDOJI}'
        if CDLDOJI_col not in df_all_encoded.columns:
            df_all_encoded[CDLDOJI_col] = 0
    df_all_encoded = df_all_encoded.drop(columns = ['datetime'])

    df_all_encoded = df_all_encoded[column_names]

    if model == 1:
        predict = XGB.predict(df_all_encoded)
    else:
        predict = XGB2.predict(df_all_encoded)

    return {"predict": predict[0],
            "sma_10": sma_10,
            "sma_30": sma_30,
            "ema_10": ema_10,
            "rsi": rsi,
            "macd_value": macd_value,
            "cdl_doji": cdl_doji}