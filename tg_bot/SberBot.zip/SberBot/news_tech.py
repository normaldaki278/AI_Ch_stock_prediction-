import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# Компании для анализа и их ключевые слова
company_keywords = {
    'SBER': [
        'Сбербанк', 'Сбер', 'финансы', 'банк', 'банкинг', 'ипотека', 'депозит', 'вклад', 
        'кредит', 'кредитная карта', 'сбережения', 'банковская карта', 'инвестиции', 
        'платежи', 'онлайн банк', 'перевод денег', 'мобильный банк', 'сберегательный счет', 
        'банковский счет', 'финансовая аналитика', 'филиал Сбербанка', 'банковская операция', 
        'финансовые услуги', 'финансовая помощь', 'СберТех', 'СберИнвест', 'СберКредит', 
        'СберЗдоровье', 'сервис Сбера', 'цифровой банк', 'финансовый сектор', 'кредитование бизнеса'
    ],
    'AGRO': [
        'Агрокомплекс', 'сельское хозяйство', 'агропром', 'агро', 'продовольствие', 'фермерство', 
        'агробизнес', 'пищевое производство', 'продукты питания', 'производство молока', 
        'молочная ферма', 'зерно', 'урожай', 'производство зерна', 'животноводство', 
        'аграрный сектор', 'аграрные технологии', 'органическое земледелие', 'агропромышленный комплекс', 
        'производство мясных продуктов', 'выращивание овощей', 'теплицы', 'зеленые технологии', 
        'сельхозпродукты', 'агротехника', 'агроиндустрия', 'сельхозмашины', 'фермерские хозяйства'
    ],
    'CHMF': [
        'Северсталь', 'металлургия', 'металлургический комбинат', 'чёрная металлургия', 
        'сталь', 'производство стали', 'сталелитейный завод', 'стальной прокат', 'металлопрокат', 
        'сплавы', 'железо', 'стальные изделия', 'металлоконструкции', 'металлы', 'горная промышленность', 
        'рудники', 'добыча металлов', 'стальная промышленность', 'железорудная промышленность', 
        'металлургический сектор', 'сталелитейная продукция', 'производство металлов', 'сплавы стали', 
        'железорудные предприятия', 'обогащение руды', 'металлообработка', 'прокатное производство'
    ],
    'MTSS': [
        'МТС', 'Мобильные Телесистемы', 'телекоммуникации', 'связь', 'интернет', 'мобильная связь', 
        'телефон', 'сотовая связь', 'сотовый оператор', 'оператор связи', 'телеком', 'цифровая связь', 
        'мобильные услуги', 'мобильные приложения', 'тарифы МТС', 'мобильные технологии', 'беспроводная связь', 
        'смартфоны', 'подключение интернета', 'домашний интернет', 'мобильные тарифы', 'пакеты услуг связи', 
        'МТС Банк', 'интернет-пакеты', '4G', '5G', 'оптоволокно', 'телекоммуникационные услуги'
    ],
    'SIBN': [
        'Газпромнефть', 'нефть', 'добыча нефти', 'транспортировка нефти', 'газ', 'нефтяная промышленность', 
        'газовая промышленность', 'энергетика', 'энергоресурсы', 'топливо', 'нефтехимия', 'переработка нефти', 
        'нефтеперерабатывающий завод', 'топливная промышленность', 'нефтяной сектор', 'газодобыча', 
        'сжиженный газ', 'нефтяные продукты', 'нефтепродукты', 'нефтедобыча', 'разведка месторождений', 
        'нефтяные скважины', 'газопровод', 'добыча углеводородов', 'энергетические ресурсы', 
        'бурение скважин', 'экспорт нефти', 'транспортировка газа'
    ],
    'SMLT': [
        'СМЛТ', 'энергетика', 'теплоэнергия', 'электроэнергия', 'электроснабжение', 'электрические сети', 
        'теплоснабжение', 'инфраструктура', 'энергосети', 'энергосбыт', 'теплофикация', 
        'системы теплоэнергии', 'электричество', 'снабжение электричеством', 'энергосектор', 
        'энергокомпания', 'поставки тепла', 'энергетические мощности', 'тарифы на электроэнергию', 
        'энергетические ресурсы', 'производство электричества', 'генерация электроэнергии', 
        'сетевые компании', 'электростанции', 'энергогенерация', 'производство энергии'
    ],
    'VKCO': [
        'ВКонтакте', 'VK', 'социальная сеть', 'социальные сети', 'интернет-коммуникации', 'мессенджеры', 
        'VK Play', 'мобильные приложения', 'цифровая платформа', 'социальные платформы', 'контент', 
        'медиа', 'интернет', 'цифровые технологии', 'сообщения', 'чаты', 'интернет-сервисы',
        'онлайн-платформа', 'диджитал', 'медиа-платформа', 'обмен сообщениями', 'реклама в интернете', 
        'онлайн-реклама', 'интернет-маркетинг', 'мобильные платформы', 'цифровой маркетинг', 'VK Звонки'
    ],
    'YNDX': [
        'Яндекс', 'технологии', 'интернет', 'поисковая система', 'Яндекс.Такси', 'Яндекс.Маркет', 'Яндекс.Еда', 
        'Яндекс.Деньги', 'технологический гигант', 'цифровые технологии', 'онлайн-платформа', 'карты Яндекс', 
        'Яндекс.Браузер', 'облачные технологии', 'интернет-поиск', 'реклама Яндекс', 'такси', 'доставка еды', 
        'онлайн-торговля', 'маркетплейс', 'онлайн-платежи', 'интернет-магазины', 'онлайн-сервисы', 
        'интернет-коммерция', 'мобильные приложения', 'облачные сервисы', 'онлайн-реклама'
    ]
}

# Функция для поиска новостей, содержащих упоминания компании или связанных сфер
def filter_news_by_keywords(df, company):
    keywords = company_keywords.get(company, [])
    if not keywords:
        return pd.DataFrame()  # Возвращаем пустой датафрейм, если компания не найдена
    filtered_news = df[df['title'].apply(lambda title: any(keyword.lower() in title.lower() for keyword in keywords))]
    filtered_news = filtered_news.drop_duplicates(subset='title')  # Удаление дубликатов заголовков
    return filtered_news

# Функция для получения ключевых слов из заголовка на основе существующих attention-весов
def extract_keywords(headline, attention_weights):
    if isinstance(attention_weights, str):
        attention_weights = eval(attention_weights)
    
    attention_weights = np.array(attention_weights)
    tokens = headline.split()
    avg_attention = np.mean(attention_weights, axis=(0, 1))
    
    top_indices = np.argsort(avg_attention)[-5:]
    keywords = [tokens[i] for i in top_indices if i < len(tokens)]
    
    return keywords

# Функция для анализа новостей для компании
def analyze_company_news(df, company):
    # Временной диапазон - последние 7 дней
    current_date = datetime.now()
    start_time = current_date - timedelta(days=7)
    
    df['data and time'] = pd.to_datetime(df['data and time'])
    filtered_news = df[(df['data and time'] >= start_time) & (df['data and time'] <= current_date)]
    
    # Если новостей нет, возвращаем сообщение
    if filtered_news.empty:
        return f"Нет новостей для компании {company} за последние 7 дней."
    
    # Фильтрация новостей по ключевым словам
    keyword_filtered_news = filter_news_by_keywords(filtered_news, company)
    
    # Если недостаточно новостей, добавляем дополнительные
    if len(keyword_filtered_news) < 5:
        remaining_news_count = 5 - len(keyword_filtered_news)
        additional_news = filtered_news[~filtered_news.index.isin(keyword_filtered_news.index)]
        additional_news = additional_news.drop_duplicates(subset='title')
        additional_news = additional_news.sort_values(by=f"{company}_sentiment_pos", ascending=False).head(remaining_news_count)
        final_news = pd.concat([keyword_filtered_news, additional_news])
    else:
        final_news = keyword_filtered_news.head(5)
    
    # Подготовка ответа
    response = f"Новости для компании {company} за последние 7 дней:\n"
    
    total_neg, total_neu, total_pos = 0, 0, 0
    for _, row in final_news.iterrows():
        headline = row['title']
        url = row.get('link', 'URL не предоставлен')
        attention_weights = row['avg_attention_weights']

        try:
            keywords = extract_keywords(headline, attention_weights)
        except Exception as e:
            keywords = ['Ошибка извлечения ключевых слов']
        
        neg_sentiment = row[f'{company}_sentiment_neg']
        neu_sentiment = row[f'{company}_sentiment_neutral']
        pos_sentiment = row[f'{company}_sentiment_pos']

        total_neg += neg_sentiment
        total_neu += neu_sentiment
        total_pos += pos_sentiment

        # Добавляем новость в текстовый ответ
        response += f"\n<b>Заголовок: {headline}</b>\nСсылка: {url}\n"
        response += f"Ключевые слова: {', '.join(keywords)}\n"
        response += f"Негативная тональность: {neg_sentiment:.2f}, Нейтральная: {neu_sentiment:.2f}, Позитивная: {pos_sentiment:.2f}\n"
        
        # Интерпретация 
        if pos_sentiment > neg_sentiment:
            response += "Эта новость имеет преимущественно положительное влияние на компанию.\n"
        elif neg_sentiment > pos_sentiment:
            response += "Эта новость имеет преимущественно негативное влияние на компанию.\n"
        else:
            response += "Новость нейтральная.\n"

        response += "\n---\n"
    
    # Усреднённые значения для новостей
    avg_neg = total_neg / len(final_news)
    avg_neu = total_neu / len(final_news)
    avg_pos = total_pos / len(final_news)

    response += f"\nСредняя негативная тональность: {avg_neg:.4f}\n"
    response += f"Средняя нейтральная тональность: {avg_neu:.4f}\n"
    response += f"Средняя позитивная тональность: {avg_pos:.4f}\n"

    if avg_pos > avg_neg:
        response += "Новости в целом положительные, что может привести к росту цены акций компании."
    elif avg_neg > avg_pos:
        response += "Новости в целом негативные, что может привести к снижению цены акций компании."
    else:
        response += "Новости нейтральные, значительных изменений не ожидается."
    
    return response

# Чтение файла CSV с новостями
def read_news_data(file_path):
    try:
        df = pd.read_csv(file_path)
        return df
    except Exception as e:
        return None

# Основная функция для обработки запроса бота
def handle_bot_request(company):
    file_path = 'Config/Updated_Data_with_Split_Sentiments_2.csv'  # Убедитесь, что путь к файлу корректен
    df = read_news_data(file_path)
    
    if df is None:
        return "Ошибка чтения файла с новостями."
    
    response = analyze_company_news(df, company)
    return response


def interpret_indicators_for_bot(sma_10, sma_30, ema_10, rsi, macd_value, cdl_doji):
    """
    Интерпретация рыночных индикаторов для использования в боте.
    
    :param sma_10: Краткосрочная средняя (SMA 10)
    :param sma_30: Долгосрочная средняя (SMA 30)
    :param ema_10: Экспоненциальная скользящая средняя (EMA 10)
    :param rsi: Индекс относительной силы (RSI)
    :param macd_value: Значение индикатора MACD
    :param cdl_doji: Признак свечного паттерна Doji (True или False)
    
    :return: Текстовая интерпретация показателей.
    """
    interpretation = []

    # Интерпретация SMA (Simple Moving Average)
    if sma_10 > sma_30:
        interpretation.append("Краткосрочная средняя (SMA 10) выше долгосрочной (SMA 30), что указывает на общий рост.")
    else:
        interpretation.append("Краткосрочная средняя (SMA 10) ниже долгосрочной (SMA 30), что может означать, что рынок падает.")

    # Интерпретация EMA (Exponential Moving Average)
    if ema_10 > sma_10:
        interpretation.append("Текущая цена выше средней, что говорит о возможном продолжении роста.")
    else:
        interpretation.append("Текущая цена ниже средней, что указывает на замедление роста или возможное снижение.")

    # Интерпретация RSI (Relative Strength Index)
    if rsi > 70:
        interpretation.append("Индекс RSI выше 70, рынок перекуплен, возможна коррекция (снижение).")
    elif rsi < 30:
        interpretation.append("Индекс RSI ниже 30, рынок перепродан, возможен рост.")
    else:
        interpretation.append(f"RSI находится на уровне {rsi:.2f}, что указывает на сбалансированное состояние рынка.")

    # Интерпретация MACD (Moving Average Convergence Divergence)
    if macd_value > 0:
        interpretation.append("MACD выше 0, что говорит о восходящем тренде и возможном росте.")
    else:
        interpretation.append("MACD ниже 0, что указывает на нисходящий тренд и возможное падение.")

    # Интерпретация свечного паттерна Doji
    if cdl_doji:
        interpretation.append("Обнаружен паттерн Doji, который может говорить о неопределенности на рынке и возможном развороте.")
    else:
        interpretation.append("Свечный паттерн Doji не обнаружен, рынок в определенном направлении.")

    # Общий вывод на основе индикаторов
    if sma_10 > sma_30 and macd_value > 0 and rsi < 70:
        summary = "Рынок выглядит стабильным с возможным дальнейшим ростом. Возможно, это хорошее время для покупки."
    elif sma_10 < sma_30 and macd_value < 0 and rsi > 70:
        summary = "Рынок кажется перегретым и может скоро упасть. Остерегайтесь инвестиций, возможно, стоит подождать."
    elif cdl_doji:
        summary = "Рынок показывает признаки неопределенности. Лучше не принимать поспешных решений."
    else:
        summary = "Рынок находится в сбалансированном состоянии. Можно следить за развитием событий, но пока что нет сильных сигналов для покупки или продажи."

    # Собираем интерпретацию в один текст
    full_interpretation = "\n\n".join([f"<b>Технический анализ:</b>\nsma10 = {sma_10:.2f}\nsma30 = {sma_30:.2f}\nMACD = {macd_value:.2f}"] + interpretation) + f"\n\n<b>Общий вывод</b>:\n {summary}"

    return full_interpretation