import asyncio
from telebot.async_telebot import AsyncTeleBot
from telebot.types import ReplyKeyboardMarkup, KeyboardButton
import datacompiler as dcomp
from news_tech import handle_bot_request, interpret_indicators_for_bot


bot = AsyncTeleBot('7486981469:AAHaz8RO43vHkgwdnsFXZ1iaA_sp7P5OLmw')
user_company = {}

# Тикеры
ticker_markup = ReplyKeyboardMarkup(row_width=2, resize_keyboard=True)
tickers = ["SIBN", "SMLT", "YDEX", "AGRO", "MTSS", "CHMF", "SBER", "VKCO"]
for i in range(0, len(tickers), 2):
    ticker_markup.add(KeyboardButton(tickers[i]), KeyboardButton(tickers[i+1]))

# Меню
menu_markup = ReplyKeyboardMarkup()
menu_markup.add(KeyboardButton(text="Тех. анализ"))
menu_markup.add(KeyboardButton(text="Новости"))


@bot.message_handler(commands=['start'])
async def send_welcome(message):
    await bot.send_message(message.chat.id, text="<b>Меню с тикерами акций должно появиться у клавиатуры ↓↓↓</b>", reply_markup=ticker_markup, parse_mode="HTML")


@bot.message_handler(func=lambda message: message.text in tickers)
async def handle_tickers(message):
    result = await asyncio.to_thread(dcomp.get_info, message.text)
    model_output, current_price, line_plot, minute_price = result

    user_company[message.chat.id] = (message.text, model_output)

    await bot.send_message(message.chat.id,
                           f"<b>----{message.text}----\nТекущая цена: {current_price}\nЦена через час: {model_output['predict']:.2f}\nЦена через минуту: {minute_price:.2f}</b>",
                           parse_mode="HTML"
                           )
    await bot.send_photo(message.chat.id, line_plot, reply_markup=menu_markup)


@bot.message_handler(func=lambda message: message.text in ["Тех. анализ", "Новости"])
async def handle_tickers(message):
    try:
        name, model_output = user_company[message.chat.id]
    except:
        await bot.send_message(message.chat.id, "Пожалуйста выберите компанию", reply_markup=ticker_markup)
    
    if message.text == "Тех. анализ":
        tech_anal = await asyncio.to_thread(interpret_indicators_for_bot,
                                            sma_10 = model_output['sma_10'],
                                            sma_30 = model_output['sma_30'],
                                            ema_10 = model_output['ema_10'],
                                            rsi = model_output['rsi'],
                                            macd_value = model_output['macd_value'],
                                            cdl_doji = model_output['cdl_doji'])
        candle_plot = await asyncio.to_thread(dcomp.draw_candle_plot, name, model_output['predict'])

        await bot.send_photo(message.chat.id, candle_plot)
        await bot.send_message(message.chat.id, tech_anal, reply_markup=ticker_markup, parse_mode="HTML")
    elif message.text == "Новости":
        news = await asyncio.to_thread(handle_bot_request, name)
        await bot.send_message(message.chat.id, news, reply_markup=ticker_markup, parse_mode="HTML")



if __name__=="__main__":
    dcomp.authorise()
    asyncio.run(bot.infinity_polling())